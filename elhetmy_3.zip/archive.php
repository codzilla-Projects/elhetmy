<?php get_header(); ?>
<h1>Archive page</h1>
<?php get_footer(); ?>