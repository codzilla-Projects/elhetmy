<?php get_header(); ?>
<h1>Page not found</h1>
<?php get_footer(); ?>