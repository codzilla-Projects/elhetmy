<?php 
switch ( ICL_LANGUAGE_CODE ){
    case 'en':
        $contact_form_title                  = get_option('contact_form_title');
        $contact_form_content                = get_option('contact_form_content');
        $contact_form_shortcode              = get_option('contact_form_shortcode');
        break;
    case 'ar':
        $contact_form_title                  = get_option('contact_form_title_ar');
        $contact_form_content                = get_option('contact_form_content_ar');
        $contact_form_shortcode              = get_option('contact_form_shortcode_ar');
        break;
    default:
        $contact_form_title                  = '';
        $contact_form_content                = '';
        $contact_form_shortcode              = '';
}